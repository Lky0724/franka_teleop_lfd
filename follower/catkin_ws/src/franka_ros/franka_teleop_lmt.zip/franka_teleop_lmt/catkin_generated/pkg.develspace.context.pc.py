# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/student1/catkin_ws/src/franka_ros/franka_teleop_lmt/devel/include;/home/student1/catkin_ws/src/franka_ros/franka_teleop_lmt/include;/opt/ros/noetic/include".split(';') if "/home/student1/catkin_ws/src/franka_ros/franka_teleop_lmt/devel/include;/home/student1/catkin_ws/src/franka_ros/franka_teleop_lmt/include;/opt/ros/noetic/include" != "" else []
PROJECT_CATKIN_DEPENDS = "controller_interface;dynamic_reconfigure;eigen_conversions;franka_hw;franka_gripper;geometry_msgs;hardware_interface;tf;tf_conversions;message_runtime;pluginlib;realtime_tools;roscpp".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lfranka_teleop_lmt;/opt/ros/noetic/lib/x86_64-linux-gnu/libfranka.so.0.9.2".split(';') if "-lfranka_teleop_lmt;/opt/ros/noetic/lib/x86_64-linux-gnu/libfranka.so.0.9.2" != "" else []
PROJECT_NAME = "franka_teleop_lmt"
PROJECT_SPACE_DIR = "/home/student1/catkin_ws/src/franka_ros/franka_teleop_lmt/devel"
PROJECT_VERSION = "0.8.2"
